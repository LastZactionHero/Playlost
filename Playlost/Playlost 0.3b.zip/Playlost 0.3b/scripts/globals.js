gViewport = null;
gPlaylist = null;
gActiveIdx = 0;
gQueue = null;
gPlayer = null;