//
// Class: Coord
// 
function Coord( x, y )
{
	this.x = x;
	this.y = y;
} // Coord